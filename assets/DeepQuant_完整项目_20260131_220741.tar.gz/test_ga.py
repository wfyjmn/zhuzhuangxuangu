"""测试遗传算法优化器"""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'assets'))

from genetic_optimizer import GeneticOptimizer
import pandas as pd
import json
import copy

def test_genetic_optimizer():
    print("[测试] 开始测试遗传算法优化器...")

    # 加载测试数据
    print("[测试] 加载测试数据...")
    df = pd.read_csv('assets/validation_records.csv')
    print(f"[测试] 加载了 {len(df)} 条验证记录")

    # 临时修改配置以进行快速测试
    print("[测试] 读取配置文件...")
    with open('assets/strategy_params_optimized.json', 'r', encoding='utf-8') as f:
        original_config = json.load(f)

    # 创建快速测试配置
    test_config = copy.deepcopy(original_config)
    test_config['genetic_algorithm']['population_size'] = 5  # 快速测试：5个个体
    test_config['genetic_algorithm']['generations'] = 3      # 快速测试：3代

    # 保存临时配置
    test_config_path = 'assets/strategy_params_test.json'
    print(f"[测试] 创建临时配置: {test_config_path}")
    with open(test_config_path, 'w', encoding='utf-8') as f:
        json.dump(test_config, f, indent=2, ensure_ascii=False)

    # 初始化优化器
    print("[测试] 初始化遗传算法优化器...")
    optimizer = GeneticOptimizer(config_path=test_config_path)

    # 运行优化
    print("[测试] 运行遗传算法优化（快速测试模式）...")
    print("[提示] 使用较小的种群和代数进行快速验证...")
    print("="*60)

    best_params = optimizer.optimize(df)

    print("\n" + "="*60)
    print("[测试结果]")
    print(f"原始阈值: {original_config['thresholds']['SCORE_THRESHOLD_NORMAL']}")
    print(f"进化阈值: {best_params['thresholds']['SCORE_THRESHOLD_NORMAL']}")
    print(f"适应度历史: {optimizer.fitness_history[-1] if optimizer.fitness_history else '无'}")

    print("\n[测试] 遗传算法优化器测试完成！")

    # 清理临时文件
    if os.path.exists(test_config_path):
        os.remove(test_config_path)
        print("[清理] 已删除临时配置文件")

if __name__ == '__main__':
    test_genetic_optimizer()
