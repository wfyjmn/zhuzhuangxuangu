#!/usr/bin/env python3
"""
测试脚本 - 验证改进的功能
功能：
1. 测试数据采集是否能获取资金流和复权因子
2. 测试特征工程是否能正确计算特征
3. 验证数据质量
"""

import sys
import os
import pandas as pd
import numpy as np

# 添加路径
workspace_path = os.getenv("COZE_WORKSPACE_PATH", "/workspace/projects")
sys.path.insert(0, os.path.join(workspace_path, "src"))

from stock_system.enhanced_features import EnhancedFeatureEngineer
from stock_system.data_collector import MarketDataCollector


def test_data_collection():
    """测试数据采集"""
    print("=" * 60)
    print("测试1: 数据采集（包含资金流和复权因子）")
    print("=" * 60)
    
    collector = MarketDataCollector()
    
    # 获取一只股票的数据进行测试
    test_code = "000001.SZ"
    start_date = "2023-01-01"
    end_date = "2023-12-31"
    
    print(f"\n获取股票 {test_code} 的数据...")
    df = collector.get_daily_data(test_code, start_date, end_date)
    
    if df is None or df.empty:
        print("✗ 数据采集失败")
        return False
    
    print(f"\n✓ 数据采集成功，共 {len(df)} 条记录")
    print(f"\n数据列:")
    for col in df.columns:
        print(f"  - {col}")
    
    # 检查关键列
    print(f"\n关键检查:")
    
    # 检查资金流数据
    moneyflow_cols = [
        'buy_elg_vol', 'sell_elg_vol', 'buy_lg_vol', 'sell_lg_vol',
        'buy_sm_vol', 'sell_sm_vol', 'net_mf_vol', 'net_mf_amount'
    ]
    has_moneyflow = any(col in df.columns for col in moneyflow_cols)
    
    if has_moneyflow:
        print(f"  ✓ 检测到资金流数据")
        for col in moneyflow_cols:
            if col in df.columns:
                print(f"    - {col}: 存在")
    else:
        print(f"  ⚠ 未检测到资金流数据（可能需要Tushare积分）")
    
    # 检查复权因子
    has_adj_factor = 'adj_factor' in df.columns
    if has_adj_factor:
        print(f"  ✓ 检测到复权因子 (adj_factor)")
        print(f"    adj_factor 范围: {df['adj_factor'].min():.4f} ~ {df['adj_factor'].max():.4f}")
    else:
        print(f"  ✗ 未检测到复权因子")
    
    # 检查换手率
    has_turnover = 'turnover_rate' in df.columns
    if has_turnover:
        print(f"  ✓ 检测到换手率 (turnover_rate)")
    else:
        print(f"  ✗ 未检测到换手率")
    
    return True, df, has_moneyflow, has_adj_factor, has_turnover


def test_feature_engineering(df, has_moneyflow, has_adj_factor):
    """测试特征工程"""
    print("\n" + "=" * 60)
    print("测试2: 特征工程")
    print("=" * 60)
    
    engineer = EnhancedFeatureEngineer()
    
    print("\n正在计算特征...")
    df_feat = engineer.create_all_features(df)
    
    if df_feat is None or df_feat.empty:
        print("✗ 特征工程失败")
        return False
    
    print(f"\n✓ 特征工程完成，共 {len(df_feat.columns)} 个特征")
    
    # 检查主力资金特征
    print(f"\n主力资金特征检查:")
    if has_moneyflow:
        main_features = [
            'main_net_inflow', 'main_flow_rate', 'main_flow_persistence',
            'retail_panic_ratio', 'main_net_inflow_ma5'
        ]
        for feat in main_features:
            if feat in df_feat.columns:
                print(f"  ✓ {feat}: 存在")
            else:
                print(f"  ✗ {feat}: 缺失")
    else:
        print(f"  ⚠ 使用代理指标计算主力资金特征")
    
    # 检查复权价格特征
    print(f"\n复权价格特征检查:")
    if has_adj_factor:
        adj_features = ['adj_close', 'adj_open', 'adj_high', 'adj_low']
        for feat in adj_features:
            if feat in df_feat.columns:
                print(f"  ✓ {feat}: 存在")
            else:
                print(f"  ✗ {feat}: 缺失")
    else:
        print(f"  ⚠ 未使用复权价格")
    
    # 检查技术指标特征
    print(f"\n技术指标特征检查:")
    tech_features = ['ma_5', 'ma_20', 'rsi_6', 'macd', 'atr_14', 'volatility_20']
    for feat in tech_features:
        if feat in df_feat.columns:
            print(f"  ✓ {feat}: 存在")
        else:
            print(f"  ✗ {feat}: 缺失")
    
    # 检查市场情绪特征
    print(f"\n市场情绪特征检查:")
    sentiment_features = ['stock_sentiment', 'up_down_ratio', 'sentiment_cycle']
    for feat in sentiment_features:
        if feat in df_feat.columns:
            print(f"  ✓ {feat}: 存在")
        else:
            print(f"  ✗ {feat}: 缺失")
    
    return True, df_feat


def test_data_quality(df_feat):
    """测试数据质量"""
    print("\n" + "=" * 60)
    print("测试3: 数据质量检查")
    print("=" * 60)
    
    # 检查缺失值
    missing_stats = df_feat.isnull().sum()
    missing_ratio = (missing_stats / len(df_feat)) * 100
    
    print(f"\n缺失值统计:")
    high_missing = missing_ratio[missing_ratio > 20].sort_values(ascending=False)
    
    if len(high_missing) == 0:
        print(f"  ✓ 没有超过20%缺失值的特征")
    else:
        print(f"  ⚠ 以下特征缺失值超过20%:")
        for col, ratio in high_missing.items():
            print(f"    - {col}: {ratio:.1f}%")
    
    # 检查数据范围
    print(f"\n数据范围检查（前10个数值型特征）:")
    numeric_cols = df_feat.select_dtypes(include=[np.number]).columns[:10]
    
    for col in numeric_cols:
        if df_feat[col].notna().sum() > 0:
            print(f"  {col}:")
            print(f"    最小值: {df_feat[col].min():.4f}")
            print(f"    最大值: {df_feat[col].max():.4f}")
            print(f"    均值: {df_feat[col].mean():.4f}")
    
    # 检查异常值
    print(f"\n异常值检查:")
    for col in numeric_cols:
        if df_feat[col].notna().sum() > 0:
            q1 = df_feat[col].quantile(0.25)
            q3 = df_feat[col].quantile(0.75)
            iqr = q3 - q1
            lower = q1 - 1.5 * iqr
            upper = q3 + 1.5 * iqr
            
            outliers = ((df_feat[col] < lower) | (df_feat[col] > upper)).sum()
            if outliers > 0:
                print(f"  ⚠ {col}: {outliers} 个异常值 ({outliers/len(df_feat)*100:.1f}%)")
    
    return True


def main():
    """主函数"""
    print("=" * 60)
    print("开始测试改进功能")
    print(f"时间: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    try:
        # 测试1: 数据采集
        result = test_data_collection()
        if isinstance(result, tuple):
            success, df, has_moneyflow, has_adj_factor, has_turnover = result
        else:
            success = result
            df, has_moneyflow, has_adj_factor, has_turnover = None, False, False, False
        
        if not success:
            print("\n✗ 测试失败: 数据采集")
            return
        
        # 测试2: 特征工程
        result = test_feature_engineering(df, has_moneyflow, has_adj_factor)
        if isinstance(result, tuple):
            success, df_feat = result
        else:
            success = result
            df_feat = None
        
        if not success:
            print("\n✗ 测试失败: 特征工程")
            return
        
        # 测试3: 数据质量
        success = test_data_quality(df_feat)
        
        if not success:
            print("\n✗ 测试失败: 数据质量检查")
            return
        
        print("\n" + "=" * 60)
        print("✓ 所有测试通过!")
        print("=" * 60)
        
        # 总结
        print(f"\n总结:")
        print(f"  资金流数据: {'✓ 已启用' if has_moneyflow else '⚠ 未启用（使用代理指标）'}")
        print(f"  复权因子: {'✓ 已启用' if has_adj_factor else '✗ 未启用'}")
        print(f"  换手率数据: {'✓ 已启用' if has_turnover else '✗ 未启用'}")
        print(f"  特征数量: {len(df_feat.columns)}")
        
        return True
        
    except Exception as e:
        print(f"\n✗ 测试过程中发生错误: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
