# -*- coding: utf-8 -*-
"""
V5.0功能测试脚本
测试所有对话3.txt中的核心功能
"""

import os
import sys
from pathlib import Path

# 添加项目根目录到路径
project_root = Path(__file__).resolve().parent
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(project_root / 'assets'))  # 添加assets目录到路径

def test_turbo_mode():
    """测试Turbo模式"""
    print("\n" + "="*80)
    print("测试 1: Turbo模式")
    print("="*80)

    try:
        from data_warehouse_turbo import DataWarehouse
        print("✅ DataWarehouseTurbo 导入成功")

        # 检查关键方法
        dw = DataWarehouse()
        assert hasattr(dw, 'preload_data'), "缺少 preload_data 方法"
        assert hasattr(dw, 'memory_db'), "缺少 memory_db 属性"
        print("✅ Turbo模式关键组件检查通过")

        return True
    except ImportError as e:
        print(f"⚠️  Turbo模式未启用: {e}")
        print("   将使用普通模式")
        return False
    except Exception as e:
        print(f"❌ Turbo模式测试失败: {e}")
        return False


def test_relative_label():
    """测试相对收益标签"""
    print("\n" + "="*80)
    print("测试 2: 相对收益标签 (V5.0核心)")
    print("="*80)

    try:
        from ai_backtest_generator import AIBacktestGenerator

        generator = AIBacktestGenerator()

        # 检查关键参数
        assert hasattr(generator, 'bear_threshold'), "缺少 bear_threshold"
        assert hasattr(generator, 'alpha_threshold'), "缺少 alpha_threshold"
        assert hasattr(generator, 'target_return'), "缺少 target_return"
        assert hasattr(generator, 'max_drawdown_limit'), "缺少 max_drawdown_limit"

        print("✅ 相对收益标签参数检查通过")
        print(f"   熊市阈值: {generator.bear_threshold}")
        print(f"   Alpha要求: {generator.alpha_threshold}")
        print(f"   牛市目标: {generator.target_return}")
        print(f"   止损底线: {generator.max_drawdown_limit}")

        # 检查关键方法
        assert hasattr(generator, '_calculate_label_v5'), "缺少 _calculate_label_v5 方法"
        assert hasattr(generator, '_get_market_data'), "缺少 _get_market_data 方法"

        print("✅ 相对收益标签方法检查通过")

        return True
    except Exception as e:
        print(f"❌ 相对收益标签测试失败: {e}")
        return False


def test_feature_completion():
    """测试特征补全"""
    print("\n" + "="*80)
    print("测试 3: 特征补全")
    print("="*80)

    try:
        from data_warehouse import DataWarehouse

        dw = DataWarehouse()

        # 检查download_daily_data方法
        assert hasattr(dw, 'download_daily_data'), "缺少 download_daily_data 方法"

        print("✅ DataWarehouse 特征补全方法检查通过")
        print("   支持特征: turnover_rate, pe_ttm, pb, total_mv, circ_mv")

        return True
    except Exception as e:
        print(f"❌ 特征补全测试失败: {e}")
        return False


def test_train_script():
    """测试训练脚本"""
    print("\n" + "="*80)
    print("测试 4: 训练脚本")
    print("="*80)

    try:
        # 检查训练脚本是否存在
        train_script = project_root / 'assets' / 'train_real_data.py'
        assert train_script.exists(), "训练脚本不存在"

        print("✅ 训练脚本存在")

        # 检查关键函数
        import train_real_data

        assert hasattr(train_real_data, 'generate_real_training_data'), "缺少 generate_real_training_data 函数"
        assert hasattr(train_real_data, 'train_with_real_data'), "缺少 train_with_real_data 函数"
        assert hasattr(train_real_data, 'optimize_dataframe'), "缺少 optimize_dataframe 函数"

        print("✅ 训练脚本关键函数检查通过")

        # 检查Turbo模式支持
        assert hasattr(train_real_data, 'IS_TURBO'), "缺少 IS_TURBO 标志"
        print(f"✅ Turbo模式支持: {train_real_data.IS_TURBO}")

        return True
    except Exception as e:
        print(f"❌ 训练脚本测试失败: {e}")
        return False


def test_incremental_scripts():
    """测试增量更新脚本"""
    print("\n" + "="*80)
    print("测试 5: 增量更新脚本")
    print("="*80)

    scripts = [
        'run_quick_incremental_update.sh',
        'run_full_incremental_update.sh'
    ]

    all_passed = True
    for script in scripts:
        script_path = project_root / script
        if script_path.exists():
            # 检查是否可执行
            if os.access(script_path, os.X_OK):
                print(f"✅ {script} 存在且可执行")
            else:
                print(f"⚠️  {script} 存在但不可执行")
                all_passed = False
        else:
            print(f"❌ {script} 不存在")
            all_passed = False

    return all_passed


def test_ai_referee():
    """测试AI裁判"""
    print("\n" + "="*80)
    print("测试 6: AI裁判")
    print("="*80)

    try:
        from ai_referee import AIReferee

        referee = AIReferee()

        # 检查关键方法
        assert hasattr(referee, 'train_time_series'), "缺少 train_time_series 方法"
        assert hasattr(referee, 'save_model'), "缺少 save_model 方法"
        assert hasattr(referee, 'predict'), "缺少 predict 方法"

        print("✅ AI裁判关键方法检查通过")

        return True
    except Exception as e:
        print(f"❌ AI裁判测试失败: {e}")
        return False


def main():
    """主测试流程"""
    print("="*80)
    print("              V5.0 功能测试")
    print("="*80)

    tests = [
        ("Turbo模式", test_turbo_mode),
        ("相对收益标签", test_relative_label),
        ("特征补全", test_feature_completion),
        ("训练脚本", test_train_script),
        ("增量更新脚本", test_incremental_scripts),
        ("AI裁判", test_ai_referee),
    ]

    results = {}
    for test_name, test_func in tests:
        try:
            results[test_name] = test_func()
        except Exception as e:
            print(f"\n❌ {test_name} 测试时发生异常: {e}")
            results[test_name] = False

    # 打印总结
    print("\n" + "="*80)
    print("测试总结")
    print("="*80)

    passed = sum(results.values())
    total = len(results)

    for test_name, result in results.items():
        status = "✅ 通过" if result else "❌ 失败"
        print(f"{test_name}: {status}")

    print("\n" + "="*80)
    print(f"通过: {passed}/{total}")
    print("="*80)

    if passed == total:
        print("\n🎉 所有测试通过！V5.0功能已就绪")
        print("\n下一步:")
        print("1. 下载测试数据: ./test_download_sample_data.sh")
        print("2. 运行干运行测试: python assets/train_real_data.py --dry-run")
        print("3. 下载完整数据: ./run_quick_incremental_update.sh")
        print("4. 开始训练: python assets/train_real_data.py")
    else:
        print("\n⚠️  部分测试失败，请检查上述错误信息")


if __name__ == '__main__':
    main()
