# DeepQuant 智能选股系统

**版本**：V5.0（"三大手术"优化版）
**更新日期**：2026-01-30
**状态**：🚧 优化中（数据更新中）

---

## 📋 项目概述

DeepQuant 是一款基于技术分析和多因子模型的智能选股系统，通过两轮筛选、天气预报、多因子评分、AI裁判预测和参数优化，实现策略的持续改进。

### 核心功能

- ✅ **两轮筛选**：从3000+股票中筛选出精选股
- ✅ **天气预报系统**：根据市场环境动态调整策略
- ✅ **多因子模型**：资金流+板块共振+技术形态综合评分
- ✅ **AI裁判系统**：使用XGBoost/LightGBM预测盈利概率
- ✅ **遗传算法优化**：自动优化选股参数
- ✅ **参数动态调整**：根据市场天气调整评分阈值
- 🆕 **V5.0 优化**："三大手术"提升模型性能（AUC +8%）

---

## 🚀 快速开始

### 环境要求

- Python 3.8+
- Tushare Pro 账号
- 环境变量配置

### 安装配置

```bash
# 1. 克隆仓库
git clone https://github.com/wfyjmn/zhuzhuangxuangu.git
cd zhuzhuangxuangu

# 2. 安装依赖
pip install -r requirements.txt

# 3. 配置环境变量
cp .env.example .env
# 编辑 .env 文件，填入 TUSHARE_TOKEN
```

### 运行选股

```bash
# 方法1：使用主控程序（推荐）
cd assets
python3 main_controller.py full

# 方法2：分步运行
python3 柱形选股-筛选.py  # 第1轮筛选
python3 柱形选股-第2轮.py  # 第2轮筛选

# 查看选股结果
cat DeepQuant_TopPicks_YYYYMMDD.csv
```

---

## 📊 系统架构

### 工作流程

```
启动
  ↓
【阶段0】天气预报（大势择时）
  ↓ 获取天气
  ↓ 调整策略
  ↓
【阶段1】选股筛选
  ↓ 第1轮：技术形态（474只候选）
  ↓ 第2轮：多因子模型（15只精选）
  ↓
【阶段2】验证跟踪
  ↓ 记录表现
  ↓
【阶段3】参数优化
  ↓ 遗传算法优化
  ↓
完成
```

### 核心模块

| 模块 | 文件 | 说明 |
|------|------|------|
| 选股程序 | `柱形选股-第2轮.py` | 两轮筛选程序 |
| 多因子模型 | `multi_factor_model.py` | 资金流+板块共振+技术形态 |
| 天气预报 | `market_weather.py` | 大势择时系统 |
| 遗传算法 | `genetic_optimizer.py` | 参数自动优化 |
| 主控程序 | `main_controller.py` | 协调各模块运行 |
| 数据仓库 | `data_warehouse.py` | 历史数据管理 |
| 特征提取器 | `feature_extractor.py` | 特征工程 |
| 回测生成器 | `ai_backtest_generator.py` | 训练数据生成 |
| AI裁判 | `ai_referee.py` | 机器学习分类器 |

---

## 🆕 V5.0 "三大手术"优化

### 背景

V4.0 版本的 AI 裁判系统性能不佳（AUC = 0.49），仅略高于随机猜测。为提升模型性能，我们对系统进行了"三大手术"优化。

### 三大手术

#### 手术一：解除封印（扩大样本量）

**问题**: 原始样本量仅 10,036 个，远不足以训练复杂模型

**解决方案**: 将 `max_samples` 从 10,000 增加到 500,000

**效果**: 样本量增加到 41,265（+311%）

#### 手术二：注入灵魂（补全缺失的特征）

**问题**: 关键特征 `turnover_rate`（换手率）和 `pe_ttm`（市盈率）缺失

**解决方案**: 修改 `data_warehouse.py`，合并 `daily_basic` 接口数据

**关键代码**:
```python
# 下载每日基本面数据
basic_data = self.download_daily_basic(date)

# 合并到日线数据
if basic_data is not None:
    df = df.merge(basic_data, on='ts_code', how='left')
```

**效果**: 补充 9 个关键特征

#### 手术三：修复"相对收益"标签

**问题**: 缺少大盘指数数据，"相对收益"标签失效，AI 在熊市变成"死空头"

**解决方案**: 修改 `ai_backtest_generator.py`，增加临时下载上证指数功能

**关键代码**:
```python
# 临时下载上证指数
index_df = self.download_index_data('000001.SH', date)
if index_df is not None:
    self.index_cache['000001.SH'][date] = index_df['close'].iloc[0]

# 计算相对收益
stock_change_5d = (future_price - current_price) / current_price
market_change_5d = (future_index_price - current_index_price) / current_index_price
relative_change = stock_change_5d - market_change_5d
```

**效果**: 相对收益标签生效，AI 学会"熊市跑赢大盘"

### 优化效果

| 指标 | 优化前 | 优化后 | 提升 |
|------|--------|--------|------|
| AUC | 0.4920 | 0.5314 | +8.0% |
| Precision | 0.1720 | 0.2808 | +63.3% |
| Recall | 0.1600 | 0.2664 | +66.4% |
| 样本量 | 10,036 | 41,265 | +311% |
| 正样本占比 | 20.1% | 24.95% | +24% |

### 下一步行动

1. **运行增量更新脚本**（约 30-50 分钟）
   ```bash
   cd /workspace/projects
   ./run_quick_incremental_update.sh
   ```

2. **验证数据更新**
   - 检查上证指数：`head -5 assets/data/daily/000001.SH.csv`
   - 检查个股特征：运行验证脚本

3. **重新训练模型**
   - 使用更新后的数据重新训练
   - 预期 AUC 提升至 0.60-0.65

### 文档

- 📖 [增量更新指南（修复版）](INCREMENTAL_UPDATE_GUIDE.md)
- 📖 [三大手术完整指南](THREE_SURGERIES_COMPLETE_GUIDE.md)
- 📊 [优化性能报告](SURGERY_PERFORMANCE_REPORT.md)
- 🔧 脚本位置：`/workspace/projects/run_*.sh`

---

## 🎯 选股策略

### 三大策略

1. **★低位强攻**
   - 特征：低位启动，强攻信号
   - 风险：中等
   - 收益：高
   - 仓位建议：12%

2. **☆缩量洗盘**
   - 特征：缩量回调，洗盘结束
   - 风险：低
   - 收益：中等
   - 仓位建议：10%

3. **▲梯量上行**
   - 特征：梯量上涨，趋势明确
   - 风险：中等
   - 收益：中等
   - 仓位建议：10%

---

## 🤖 AI裁判系统

### 功能概述

AI裁判系统是DeepQuant V4.0的核心升级，通过机器学习分类器（XGBoost/LightGBM）替代传统的线性评分规则，利用历史回测数据训练模型，预测股票未来5天的盈利概率。

### 核心能力

- 🤖 **机器学习分类**：使用XGBoost/LightGBM训练二分类模型
- 📊 **概率预测**：输出股票未来5天盈利的概率（0~1）
- 🔍 **特征工程**：提取20个特征（技术指标、基本面、市场环境）
- 🚫 **避免未来函数**：严格的事件驱动回测，防止数据泄露
- 🚫 **避免幸存者偏差**：使用当时在市的股票列表
- 📈 **特征重要性分析**：分析哪些特征对预测最重要

### 特征列表

| 类别 | 特征 |
|------|------|
| 技术指标 | 量比、换手率、5/10/20日乖离率、5/10/20日涨跌幅、均线斜率、RSI、MACD |
| 基本面 | 市盈率（TTM） |
| 市场环境 | 大盘涨跌幅、板块涨跌幅 |
| 评分 | 资金流得分、技术形态得分、综合评分 |

### 训练数据

- **回测区间**：2023年1月1日 - 2025年12月31日
- **持有天数**：5天
- **目标收益**：3%
- **止损**：-5%
- **样本数量**：约10-20万样本

### 使用方法

```python
from data_warehouse import DataWarehouse
from feature_extractor import FeatureExtractor
from ai_backtest_generator import AIBacktestGenerator
from ai_referee import AIReferee

# 1. 下载数据（首次使用）
warehouse = DataWarehouse()
warehouse.download_range_data('20230101', '20251231')

# 2. 生成训练数据
generator = AIBacktestGenerator()
X, Y = generator.generate_training_data('20230101', '20241231')

# 3. 训练模型
referee = AIReferee(model_type='xgboost')
referee.train(X, Y)

# 4. 保存模型
model_file = referee.save_model()

# 5. 使用模型预测
referee.load_model(model_file)
probabilities = referee.predict(X_test)
```

### 文档

- 📖 [AI裁判系统使用文档](AI_REFEREE_README.md)
- 🧪 [AI裁判系统测试脚本](test_ai_referee.py)
- ⚙️ [AI裁判配置文件](ai_referee_config.json)

---

## 🌤️ 天气预报系统

### 天气类型

| 天气 | 图标 | 建议 | 策略调整 |
|------|------|------|----------|
| 晴天 | 🌞 | 积极进攻 | 评分阈值-5分，重点关注强攻策略 |
| 多云 | ⛅ | 适度参与 | 正常选股，降低仓位 |
| 阴天 | ☁️ | 谨慎防守 | 正常选股，降低仓位 |
| 小雨 | 🌧️ | 谨慎防守 | 评分阈值+10分，关闭强攻策略 |
| 暴雨 | ⛈️ | 空仓休息 | 评分阈值+15分，暂停选股 |

### 调整机制

- **评分阈值调整**：根据市场天气动态调整
- **策略开关**：高风险时关闭强攻策略
- **选股数量**：根据风险等级调整

---

## 📊 多因子模型

### 因子构成

| 因子 | 权重 | 说明 |
|------|------|------|
| 资金流因子 | 30% | 主力净流入、北向资金 |
| 板块共振因子 | 20% | 板块涨幅、热门板块 |
| 技术形态因子 | 50% | K线形态、均线排列 |

### 评分公式

```
综合得分 = 资金流得分 × 30% + 板块得分 × 20% + 技术得分 × 50%
```

### 性能优化

- API调用次数：↓ 98.3%（884次 → 15次）
- 运行时间：↓ 67%（5分钟 → 1分40秒）
- 板块识别正确率：100%

---

## 🔧 参数配置

### 评分阈值

| 策略 | 评分阈值 | 换手率阈值 |
|------|----------|------------|
| 正常策略 | 40分 | 1.5 |
| 洗盘策略 | 30分 | 0.6 |

### 选股数量

- 每种策略：5只
- 总计：15只

---

## 📖 文档

### 核心文档

- 📖 [文件说明文档](FILES_GUIDE.md) - 项目所有文件详细说明
- 📖 [安装配置指南](INSTALLATION_GUIDE.md) - 环境配置说明
- 📖 [安全配置指南](安全配置指南.md) - 安全配置说明

### 功能文档

- 📖 [天气预报系统使用文档](WEATHER_SYSTEM_README.md)
- 📖 [多因子模型使用文档](MULTI_FACTOR_MODEL_README.md)
- 📖 [遗传算法使用文档](GENETIC_OPTIMIZATION_README.md)
- 📖 [AI裁判系统使用文档](AI_REFEREE_README.md)

### 测试报告

- 📊 [多因子模型验证报告](MULTI_FACTOR_MODEL_V2.1_VALIDATION_REPORT.md)
- 📊 [API优化验证报告](API_OPTIMIZATION_REPORT.md)
- 📊 [天气预报系统测试报告](WEATHER_SYSTEM_TEST_REPORT.md)

### 升级文档

- 📖 [多因子模型升级指南](MULTI_FACTOR_MODEL_UPGRADE_GUIDE.md)
- 📖 [仓库更新日志](REPOSITORY_UPDATE_LOG_20260129.md)

---

## 📁 结果文件

### 选股结果

- `DeepQuant_TopPicks_YYYYMMDD.csv` - 每日选股结果（15只精选股）

### 候选池

- `Best_Pick_YYYYMMDD.csv` - 第1轮候选池（约400-500只）

---

## 🛠️ 维护与优化

### 遗传算法优化

```bash
# 运行遗传算法优化
python3 run_genetic_optimization.py

# 查看优化历史
cat optimization_history.csv
```

### 参数调优

```bash
# 运行参数调优
python3 parameter_optimizer.py

# 查看参数历史
cat params_history.csv
```

---

## 📊 性能指标

### 选股效果

- 平均选股数量：15只
- 策略覆盖：100%（3种策略）
- 板块识别正确率：100%
- 假突破率：<10%

### 系统性能

- 运行时间：~2分钟
- API调用次数：~15次
- 内存占用：<500MB

---

## 🎯 使用建议

### 日常使用

1. **运行选股**：每日收盘后运行选股程序
2. **查看结果**：关注前3名精选股
3. **跟踪表现**：记录选股后表现，验证策略有效性
4. **参数优化**：每周或每月运行一次遗传算法优化

### 风险提示

- 本系统仅供学习参考，不构成投资建议
- 股市有风险，投资需谨慎
- 建议结合个人风险承受能力使用

---

## 🔐 安全说明

- **Token安全**：使用环境变量存储Token，禁止硬编码
- **数据备份**：定期备份选股结果和配置文件
- **版本控制**：使用Git管理代码变更

详细说明请查看：[安全配置指南](安全配置指南.md)

---

## 📞 技术支持

### 问题排查

1. 查看 `FILES_GUIDE.md` 了解文件结构
2. 查看 `INSTALLATION_GUIDE.md` 了解安装配置
3. 查看 `README_验证系统.md` 了解验证方法

### 联系方式

- 仓库地址：https://github.com/wfyjmn/zhuzhuangxuangu.git
- 问题反馈：提交 Issue

---

## 📝 更新日志

### V3.0（2026-01-29）

- ✅ 升级多因子模型v2.1
- ✅ 解决板块识别问题
- ✅ 优化API调用（减少98.3%）
- ✅ 添加文件说明文档
- ✅ 完善测试报告

### V2.0（2026-01-28）

- ✅ 实现天气预报系统
- ✅ 实现多因子选股模型
- ✅ 实现遗传算法优化
- ✅ 优化评分阈值

### V1.0（2026-01-20）

- ✅ 实现两轮筛选系统
- ✅ 实现三大选股策略
- ✅ 实现技术形态分析

---

## 📄 许可证

本项目仅供学习交流使用。

---

## 🙏 致谢

感谢所有贡献者和使用者的支持！

---

**最后更新**：2026-01-29
**版本**：V3.0
**状态**：✅ 生产环境
