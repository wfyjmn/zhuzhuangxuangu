# FeatureExtractor 优化说明文档

## 概述

针对 `feature_extractor.py` 中的四个关键问题进行了专业级优化修复，确保提取的特征适合机器学习模型训练。

---

## 🚨 修复的关键问题

### 1. 均线斜率未归一化（最严重问题）

**问题描述**：
原代码使用绝对价格变化计算斜率：
```python
# 原代码（错误）
latest['ma5'] - df.iloc[-2]['ma5']
```

**后果**：
- 高价股（茅台 1500元）的 MA5 一天可能变动 30元
- 低价股（工行 5元）的 MA5 一天可能变动 0.05元
- AI 会认为茅台的趋势强度是工行的 **600倍**，这显然是错误的

**修复方案**：
使用百分比斜率：
```python
# 优化后（正确）
df['ma5'].pct_change() * 100
```

**效果**：
现在，无论股价是 1000元 还是 2元，只要均线翘头的角度一样，得出的特征值就是一样的（比如都是 +1.5%）。这让 AI 模型可以跨股票学习规律。

---

### 2. RSI 除零风险

**问题描述**：
原代码：
```python
# 原代码（有风险）
rs = gain / loss
```

**后果**：
如果某只股票连续14天上涨，`loss` 为 0，程序会报错或产生 `inf`（无穷大）。

**修复方案**：
增加除零保护：
```python
# 优化后（安全）
rs = gain / (loss + 1e-9)  # 避免除零
```

---

### 3. 归一化方法太粗暴

**问题描述**：
原代码硬编码：
```python
# 原代码（粗暴）
value / 10
```

**后果**：
不同特征的量纲完全不同：
- PE 是 0-100
- 换手率是 0-20
- 涨跌幅是 -10 到 10

简单的除以10会让某些特征失效。

**修复方案**：
**删除归一化模块**，保留原始特征：

**原因**：
- **XGBoost/LightGBM** 等树模型不需要归一化（它们对数值大小不敏感，只看排序）
- 保留原始物理含义（如 PE=50）更有利于可解释性
- 如果是神经网络，可以在训练管道（Pipeline）里加 `StandardScaler`，不要写死在提取器里

---

### 4. 缺少"波动率"和"相对位置"特征

**问题描述**：
DeepQuant 的策略（洗盘、强攻）非常依赖当前价格在过去一段时间的位置（高位还是低位）。

**修复方案**：
增加两个关键特征：

```python
# 1. 相对位置 (Position)
# 当前价在过去 N 天的相对位置（0-1）
# 0 = 最低点, 1 = 最高点
df['position_20d'] = (price - low_20) / (high_20 - low_20 + 1e-9)
df['position_250d'] = (price - low_250) / (high_250 - low_250 + 1e-9)

# 2. 波动率 (Volatility)
# 衡量股价的波动程度
df['std_20_ratio'] = price.rolling(20).std() / df['ma20'] * 100
```

**应用场景**：
- `position_20d`（短期位置）：洗盘策略通常要求这个值较低（回调）
- `position_250d`（长期位置）：强攻策略通常喜欢这个值接近 1.0（突破年线新高）
- 这两个特征对 AI 判断股票所处阶段（吸筹、拉升、出货）非常有帮助

---

## 📊 优化后的特征列表（24个）

### 基础量价（3个）
- `vol_ratio`：量比
- `turnover_rate`：换手率
- `pe_ttm`：市盈率（TTM）

### 趋势特征（5个）
- `pct_chg_1d`：1日涨跌幅（动量）
- `pct_chg_5d`：5日涨跌幅
- `pct_chg_20d`：20日涨跌幅
- `ma5_slope`：5日均线斜率(%) ⭐ 修复为百分比
- `ma20_slope`：20日均线斜率(%) ⭐ 修复为百分比

### 偏离特征（2个）
- `bias_5`：5日乖离率
- `bias_20`：20日乖离率

### 震荡特征（2个）
- `rsi_14`：RSI指标（14周期）⭐ 修复除零风险
- `std_20_ratio`：20日标准差/均价（波动率）⭐ 新增

### 相对位置（2个）⭐ 新增
- `position_20d`：当前价在近20天的位置(0-1)
- `position_250d`：当前价在年线的位置(0-1)

### MACD（3个）
- `macd_dif`：MACD DIF
- `macd_dea`：MACD DEA
- `macd_hist`：MACD 红绿柱

### 环境特征（2个）
- `index_pct_chg`：大盘涨跌幅
- `sector_pct_chg`：板块涨跌幅

### 评分系统（3个）
- `moneyflow_score`：资金流得分
- `tech_score`：技术形态得分
- `new_score`：综合评分

---

## 🔧 技术改进

### 1. 自动路由复权价

```python
def _get_price_col(self, df: pd.DataFrame) -> str:
    """自动判断使用复权价还是收盘价"""
    if 'close_qfq' in df.columns:
        return 'close_qfq'
    return 'close'
```

**优势**：
- 如果 DataWarehouse 输出的数据有 `close_qfq`，就用它
- 如果没有（比如回测刚上市的新股），就降级使用 `close`
- 保证了逻辑的健壮性

### 2. 向量化计算

```python
def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
    """一次性计算所有技术指标（向量化加速）"""
    # 所有指标一次性计算，避免重复遍历
    df['ma5'] = price.rolling(window=5).mean()
    df['bias_5'] = (price - df['ma5']) / df['ma5'] * 100
    df['ma5_slope'] = df['ma5'].pct_change() * 100
    # ...
```

**优势**：
- 一次性计算所有指标
- 利用 Pandas 向量化操作，速度更快
- 避免重复遍历数据

### 3. 健壮性增强

```python
# 处理 NaN 和 inf
val = latest.get(col, 0)
features[col] = 0 if (pd.isna(val) or np.isinf(val)) else val

# 确保数据长度足够
if len(df) < 30:
    return {k: 0 for k in self.feature_names}
```

**优势**：
- 刚上市或停牌的股票不会导致程序崩溃
- 返回全0特征，而不是报错
- 保证回测流程的连续性

---

## 📈 对AI模型的改进

### 1. 特征可解释性增强

**修复前**：
```
ma5_slope: 30.0  # 茅台（绝对值，无法比较）
ma5_slope: 0.05  # 工行（绝对值，无法比较）
```

**修复后**：
```
ma5_slope: 1.5  # 茅台（百分比，可比较）
ma5_slope: 1.0  # 工行（百分比，可比较）
```

现在 AI 可以正确判断：茅台和工行的趋势强度相近。

### 2. 特征信息量增加

**新增特征**：
- `position_20d`：帮助 AI 判断当前是洗盘还是拉升
- `position_250d`：帮助 AI 判断是否突破年线
- `std_20_ratio`：帮助 AI 判断市场波动情况

### 3. 稳定性提升

**修复前**：
- RSI 可能出现 `inf`（除零）
- NaN 值可能导致训练失败

**修复后**：
- 所有 NaN 和 inf 都被替换为 0
- 保证训练过程的稳定性

---

## 🧪 测试验证

### 测试1：斜率归一化

```python
# 构造高价股和低价股
高价股 = pd.DataFrame({'close': [1500, 1515, 1530]})  # 上涨1%
低价股 = pd.DataFrame({'close': [5, 5.05, 5.10]})     # 上涨1%

# 修复前
高价股斜率 = 30
低价股斜率 = 0.05
# 高价股 / 低价股 = 600倍 ❌

# 修复后
高价股斜率 = 1.0  # 百分比
低价股斜率 = 1.0  # 百分比
# 高价股 / 低价股 = 1倍 ✅
```

### 测试2：RSI 除零保护

```python
# 连续上涨14天
price = pd.Series([10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23])

# 修复前：rsi = inf ❌
# 修复后：rsi = 100 ✅
```

### 测试3：相对位置

```python
# 模拟上涨趋势
price = pd.Series([10, 11, 12, 13, 14, 15])

# position = (15 - 10) / (15 - 10) = 1.0
# AI 可以判断：当前处于高位
```

---

## 📋 使用建议

### 1. 数据准备

确保数据包含以下列：
- `close`, `high`, `low`, `open`：原始价格
- `close_qfq`, `high_qfq`, `low_qfq`, `open_qfq`：复权价格
- `vol_ratio`, `turnover_rate`, `pe_ttm`：基础数据
- `pct_chg`：涨跌幅

### 2. 特征提取

```python
from feature_extractor import FeatureExtractor

extractor = FeatureExtractor()
features = extractor.extract_features(df)

# 返回 24 个特征
# 所有值都是原始值，没有归一化
# 适合 XGBoost/LightGBM 直接使用
```

### 3. 模型训练

```python
from ai_referee import AIReferee
from sklearn.preprocessing import StandardScaler

# 如果使用 XGBoost/LightGBM，直接使用
referee = AIReferee(model_type='xgboost')
referee.train(X, Y)

# 如果使用神经网络，需要归一化
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
```

---

## ⚠️ 注意事项

### 1. 不需要手动归一化

- **XGBoost/LightGBM**：不需要归一化，直接使用原始特征
- **神经网络**：在训练管道里加 `StandardScaler`，不要写死在提取器里

### 2. 复权价格优先

系统会自动使用复权价格（`close_qfq`），如果没有则使用原始价格（`close`）。

### 3. 数据长度要求

- 最小数据长度：30天
- 建议数据长度：120天以上（计算更准确）

---

## 🔍 特征重要性预期

根据金融经验，预期特征重要性排序：

1. **`position_250d`**：长期位置（突破年线）
2. **`ma20_slope`**：中期趋势斜率
3. **`rsi_14`**：超买超卖
4. **`std_20_ratio`**：波动率
5. **`moneyflow_score`**：资金流
6. **`bias_20`**：中期乖离率
7. **`new_score`**：综合评分
8. **`position_20d`**：短期位置
9. **`pct_chg_20d`**：中期涨跌幅
10. `ma5_slope`：短期趋势斜率

---

## 总结

通过这次优化，解决了四个关键问题：

1. ✅ **斜率归一化**：消除高低价股差异，AI可以跨股票学习
2. ✅ **除零保护**：避免 RSI 等指标出现 inf
3. ✅ **删除粗暴归一化**：保留原始物理含义，适合树模型
4. ✅ **增加关键特征**：波动率和相对位置，提升信息量

这些优化使得特征更适合机器学习模型训练，预期会显著提升 AI 裁判的预测准确率。

---

**文档版本**：v1.0
**更新日期**：2025-01-29
**作者**：DeepQuant Team
