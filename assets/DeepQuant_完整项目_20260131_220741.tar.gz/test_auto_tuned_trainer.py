# -*- coding: utf-8 -*-
"""
AutoTunedTrainer 功能测试脚本
测试对话4.txt中的所有核心功能
"""

import os
import sys
from pathlib import Path

# 添加项目根目录到路径
project_root = Path(__file__).resolve().parent
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(project_root / 'assets'))

def test_imports():
    """测试依赖导入"""
    print("\n" + "="*80)
    print("测试 1: 依赖导入")
    print("="*80)

    try:
        import optuna
        print("✅ Optuna 导入成功")

        import xgboost as xgb
        print("✅ XGBoost 导入成功")

        import pandas as pd
        print("✅ Pandas 导入成功")

        import numpy as np
        print("✅ NumPy 导入成功")

        return True
    except ImportError as e:
        print(f"❌ 导入失败: {e}")
        return False


def test_config():
    """测试配置文件"""
    print("\n" + "="*80)
    print("测试 2: 配置文件")
    print("="*80)

    try:
        import json

        config_path = project_root / 'config' / 'optuna_auto_tuned_config.json'
        assert config_path.exists(), "配置文件不存在"

        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)

        print("✅ 配置文件加载成功")
        print(f"  策略名称: {config['strategy_name']}")
        print(f"  版本: {config['version']}")
        print(f"  优化指标: {config['optuna']['metric']}")
        print(f"  目标精确率: {config['threshold']['target_precision']}")

        # 检查关键配置
        assert config['optuna']['metric'] == 'auc', "优化指标应为AUC"
        assert config['threshold']['target_precision'] == 0.60, "目标精确率应为60%"
        assert config['model']['max_bin'] == 128, "max_bin应为128"

        print("✅ 配置文件验证通过")

        return True
    except Exception as e:
        print(f"❌ 配置文件测试失败: {e}")
        return False


def test_auto_tuned_trainer():
    """测试AutoTunedTrainer类"""
    print("\n" + "="*80)
    print("测试 3: AutoTunedTrainer类")
    print("="*80)

    try:
        from auto_tuned_trainer import AutoTunedTrainer

        # 初始化
        trainer = AutoTunedTrainer('config/optuna_auto_tuned_config.json')
        print("✅ AutoTunedTrainer 初始化成功")

        # 检查关键方法
        assert hasattr(trainer, '_optimize_memory'), "缺少 _optimize_memory 方法"
        assert hasattr(trainer, '_force_gc'), "缺少 _force_gc 方法"
        assert hasattr(trainer, 'define_search_space'), "缺少 define_search_space 方法"
        assert hasattr(trainer, 'objective'), "缺少 objective 方法"
        assert hasattr(trainer, 'optimize_threshold'), "缺少 optimize_threshold 方法"

        print("✅ AutoTunedTrainer 关键方法检查通过")

        # 检查配置
        assert trainer.config['optuna']['metric'] == 'auc', "配置中优化指标应为AUC"
        assert trainer.config['threshold']['target_precision'] == 0.60, "配置中目标精确率应为60%"

        print("✅ AutoTunedTrainer 配置检查通过")

        return True
    except Exception as e:
        print(f"❌ AutoTunedTrainer 测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_memory_optimization():
    """测试内存优化功能"""
    print("\n" + "="*80)
    print("测试 4: 内存优化功能")
    print("="*80)

    try:
        from auto_tuned_trainer import AutoTunedTrainer
        import pandas as pd
        import numpy as np

        trainer = AutoTunedTrainer('config/optuna_auto_tuned_config.json')

        # 创建测试数据
        df = pd.DataFrame({
            'col1': np.random.randn(1000),
            'col2': np.random.randn(1000),
            'col3': np.random.randn(1000)
        })

        # 确保初始为 float64
        df['col1'] = df['col1'].astype('float64')
        df['col2'] = df['col2'].astype('float64')
        df['col3'] = df['col3'].astype('float64')

        print(f"  优化前: {df.dtypes.to_dict()}")

        # 应用内存优化
        df_optimized = trainer._optimize_memory(df)

        print(f"  优化后: {df_optimized.dtypes.to_dict()}")

        # 检查是否转换为 float32
        assert df_optimized['col1'].dtype == 'float32', "col1 应为 float32"
        assert df_optimized['col2'].dtype == 'float32', "col2 应为 float32"
        assert df_optimized['col3'].dtype == 'float32', "col3 应为 float32"

        print("✅ 内存优化功能正常")

        return True
    except Exception as e:
        print(f"❌ 内存优化测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_search_space():
    """测试参数搜索空间"""
    print("\n" + "="*80)
    print("测试 5: 参数搜索空间")
    print("="*80)

    try:
        from auto_tuned_trainer import AutoTunedTrainer
        import optuna

        trainer = AutoTunedTrainer('config/optuna_auto_tuned_config.json')

        # 创建测试trial
        study = optuna.create_study(direction='maximize')
        trial = study.ask()

        # 定义搜索空间
        params = trainer.define_search_space(trial)

        # 检查关键参数
        assert 'learning_rate' in params, "缺少 learning_rate 参数"
        assert 'max_depth' in params, "缺少 max_depth 参数"
        assert 'tree_method' in params, "缺少 tree_method 参数"
        assert 'max_bin' in params, "缺少 max_bin 参数"

        # 检查内存优化参数
        assert params['tree_method'] == 'hist', "tree_method 应为 hist"
        assert params['max_bin'] == 128, "max_bin 应为 128"

        # 检查scale_pos_weight是否被移除
        assert 'scale_pos_weight' not in params, "scale_pos_weight 应被移除"

        print("✅ 参数搜索空间验证通过")
        print(f"  tree_method: {params['tree_method']}")
        print(f"  max_bin: {params['max_bin']}")
        print(f"  learning_rate: {params['learning_rate']:.4f}")

        return True
    except Exception as e:
        print(f"❌ 参数搜索空间测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_data_warehouse():
    """测试数据仓库"""
    print("\n" + "="*80)
    print("测试 6: 数据仓库")
    print("="*80)

    try:
        from auto_tuned_trainer import AutoTunedTrainer

        trainer = AutoTunedTrainer('config/optuna_auto_tuned_config.json')

        # 测试获取股票列表
        stock_list = trainer.get_stock_list(n_stocks=5)

        if len(stock_list) > 0:
            print(f"✅ 获取到 {len(stock_list)} 只股票")
            print(f"  示例: {stock_list[:3]}")
            return True
        else:
            print("⚠️  未能获取股票列表（可能需要先下载数据）")
            return True  # 不算失败，只是数据缺失

    except Exception as e:
        print(f"❌ 数据仓库测试失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """主测试流程"""
    print("=" * 80)
    print("              AutoTunedTrainer 功能测试")
    print("=" * 80)

    tests = [
        ("依赖导入", test_imports),
        ("配置文件", test_config),
        ("AutoTunedTrainer类", test_auto_tuned_trainer),
        ("内存优化功能", test_memory_optimization),
        ("参数搜索空间", test_search_space),
        ("数据仓库", test_data_warehouse),
    ]

    results = {}
    for test_name, test_func in tests:
        try:
            results[test_name] = test_func()
        except Exception as e:
            print(f"\n❌ {test_name} 测试时发生异常: {e}")
            import traceback
            traceback.print_exc()
            results[test_name] = False

    # 打印总结
    print("\n" + "="*80)
    print("测试总结")
    print("="*80)

    passed = sum(results.values())
    total = len(results)

    for test_name, result in results.items():
        status = "✅ 通过" if result else "❌ 失败"
        print(f"{test_name}: {status}")

    print("\n" + "="*80)
    print(f"通过: {passed}/{total}")
    print("="*80)

    if passed == total:
        print("\n🎉 所有测试通过！AutoTunedTrainer已就绪")
        print("\n下一步:")
        print("1. 运行快速测试: python assets/auto_tuned_trainer.py")
        print("2. 后台运行训练: ./run_auto_tuned_training.sh")
        print("3. 查看训练日志: tail -f logs/auto_tuned_training.log")
    else:
        print("\n⚠️  部分测试失败，请检查上述错误信息")


if __name__ == '__main__':
    main()
